package com.example.chiquita.entities;

public record Statistics(Integer customers, Integer newCustomers, Integer products, Integer newProducts) {
}
